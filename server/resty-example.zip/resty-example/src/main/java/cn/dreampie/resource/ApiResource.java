package cn.dreampie.resource;

import cn.dreampie.route.core.Resource;
import cn.dreampie.route.annotation.API;

/**
 * Created by ice on 14-12-29.
 */
@API("/api/v1.0")
public class ApiResource extends Resource {
  /**
   * 基础的api Resource 用来添加基础的路径或版本号 和一些公用方法
   */
}
