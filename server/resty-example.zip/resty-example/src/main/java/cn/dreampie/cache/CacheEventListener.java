package cn.dreampie.cache;

/**
 * CacheEventListener
 */
public interface CacheEventListener {
  void onFlush(CacheEvent event);
}
