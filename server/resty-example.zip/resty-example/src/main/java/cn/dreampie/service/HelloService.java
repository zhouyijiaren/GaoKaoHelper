package cn.dreampie.service;

/**
 * @author Dreampie
 * @date 2015-10-08
 * @what
 */
public interface HelloService {
  public String hello();
}
