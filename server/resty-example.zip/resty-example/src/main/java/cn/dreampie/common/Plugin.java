package cn.dreampie.common;

/**
 * Plugin interface
 */
public interface Plugin {
  boolean start();

  boolean stop();
}