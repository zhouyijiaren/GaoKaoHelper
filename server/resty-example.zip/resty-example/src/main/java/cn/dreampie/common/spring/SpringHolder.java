package cn.dreampie.common.spring;

/**
 * @author Dreampie
 * @date 2015-10-08
 * @what
 */
public class SpringHolder {
  public static boolean alive = false;
}
